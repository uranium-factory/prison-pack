#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;

    if (ProjMat[2][3] == 0.0) {
        // prison: the upgrade panel (hud/UpgradeHud) into the bottom-right corner
        if ((ivec3(round(Color.rgb * 255.0)) & 7) == ivec3(1, 3, 5)) {
            float w = 2.0 / ProjMat[0][0];
            float h = -2.0 / ProjMat[1][1];
            float origin = floor(w / 2.0);
            if (Position.x >= origin - 2.0 && Position.x <= origin + 132.0 + 2.0
                    && Position.y >= 54.0 - 5.0 && Position.y <= 120.0 - 1.0) {
                vec2 shift = vec2(w - 4.0 - 132.0 - origin, h - 4.0 - 120.0 + 3.0);
                if (w - 4.0 - 132.0 < origin + 95.0) {
                    shift.y -= 52.0;
                }
                gl_Position = ProjMat * ModelViewMat * vec4(Position.xy + shift, Position.z, 1.0);
            }
        }
    }
}
