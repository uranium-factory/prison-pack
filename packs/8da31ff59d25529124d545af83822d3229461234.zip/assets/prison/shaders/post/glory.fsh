#version 330
#extension GL_ARB_separate_shader_objects : require

// Big moment (post_effect/glory_<tint>_<n>.json, PostFx#flash): glow around bright pixels, richer colour and a tinted
// wash from the screen edges, all scaled by Amount = n/8 - the server sets n = 8, holds it, then steps it down.

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform GloryConfig {
    vec3 Tint;
    float Amount;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

const int GLOW_TAPS = 12;
const float GLOW_RADIUS = 0.025;     // of screen height
const float GLOW_THRESHOLD = 0.75;

void main() {
    vec3 c = texture(InSampler, texCoord).rgb;

    // Golden-angle spiral around the pixel; only what is brighter than the threshold bleeds.
    vec3 glow = vec3(0.0);
    for (int i = 0; i < GLOW_TAPS; i++) {
        float angle = float(i) * 2.3999632;
        float radius = sqrt((float(i) + 0.5) / float(GLOW_TAPS)) * GLOW_RADIUS;
        vec2 uv = texCoord + vec2(cos(angle) * InSize.y / InSize.x, sin(angle)) * radius;
        glow += max(texture(InSampler, uv).rgb - GLOW_THRESHOLD, 0.0);
    }
    c = clamp(c + glow / float(GLOW_TAPS) * 4.0 * Amount, 0.0, 1.0);

    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(c, mix(vec3(luma), c, 1.25) * mix(vec3(1.0), Tint * 1.15, 0.25), Amount);

    vec2 p = texCoord * InSize;
    float edge = min(min(p.x, InSize.x - p.x), min(p.y, InSize.y - p.y)) / InSize.y;
    c = mix(c, Tint, (1.0 - smoothstep(0.0, 0.3, edge)) * 0.4 * Amount);

    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
