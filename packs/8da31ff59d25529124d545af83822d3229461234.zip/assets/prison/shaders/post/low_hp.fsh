#version 330
#extension GL_ARB_separate_shader_objects : require

// Low health (post_effect/low_hp.json, PostFx): red heartbeat at the edges - a double beat once a second, soft humps,
// 0.4 at the edge on a beat and 0.2 between, band 25% of the height; colour drains a little. The middle stays clear.

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

// A beat is a soft hump: up and down over 0.15 s (period 1 s) around its top at `at`.
float beat(float phase, float at) {
    return 1.0 - smoothstep(0.0, 0.15, abs(phase - at));
}

void main() {
    vec3 c = texture(InSampler, texCoord).rgb;
    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(c, vec3(luma), 0.35);

    vec2 p = texCoord * InSize;
    float edge = min(min(p.x, InSize.x - p.x), min(p.y, InSize.y - p.y)) / InSize.y;
    float mask = 1.0 - smoothstep(0.0, 0.25, edge);
    // Seconds = GameTime * 1200; 1 Hz fits 1200 s whole, so the rhythm does not skip when GameTime wraps.
    float phase = fract(GameTime * 1200.0);
    float strength = mix(0.2, 0.4, max(beat(phase, 0.15), beat(phase, 0.45)));
    fragColor = vec4(mix(c, vec3(0.75, 0.03, 0.03), mask * strength), 1.0);
}
