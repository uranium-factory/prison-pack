#version 330
#extension GL_ARB_separate_shader_objects : require

// Rest need (post_effect/tired.json, PostFx): duller, darker edges and heavy eyelids - every 6 s they half-close
// for a moment and slowly open again.

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

void main() {
    vec3 c = texture(InSampler, texCoord).rgb;
    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(c, vec3(luma), 0.3) * 0.92;

    vec2 d = (texCoord - 0.5) * vec2(InSize.x / InSize.y, 1.0);
    c *= 1.0 - 0.45 * smoothstep(0.35, 0.95, length(d));

    // Seconds = GameTime * 1200; a 6 s period fits 1200 s whole. Close over 0.3 s, open over 0.9 s.
    float phase = fract(GameTime * 1200.0 / 6.0) * 6.0;
    float lid = smoothstep(0.0, 0.3, phase) * (1.0 - smoothstep(0.3, 1.2, phase)) * 0.3;
    float fromEdge = min(texCoord.y, 1.0 - texCoord.y);
    c *= smoothstep(0.0, 0.08, fromEdge - lid + 0.08);
    fragColor = vec4(c, 1.0);
}
