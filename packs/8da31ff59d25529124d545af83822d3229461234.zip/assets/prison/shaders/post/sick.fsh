#version 330
#extension GL_ARB_separate_shader_objects : require

// Sickness need (post_effect/sick.json, PostFx): a light sickly tint, slow wobble and faint colour fringing
// toward the edges. It stays on until a pill cures it, so it must stay mild: the middle of the screen (and the
// text of holograms and name tags) barely moves.

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

void main() {
    // Seconds = GameTime * 1200; 0.25 and 0.2 Hz fit 1200 s whole, so nothing jumps when GameTime wraps.
    float t = GameTime * 1200.0;
    vec2 centered = texCoord - 0.5;
    float reach = smoothstep(0.1, 0.7, length(centered * vec2(InSize.x / InSize.y, 1.0)));
    vec2 uv = texCoord + vec2(sin(texCoord.y * 9.0 + 6.2831853 * fract(t * 0.25)),
                              cos(texCoord.x * 7.0 + 6.2831853 * fract(t * 0.2))) * 0.003 * reach;
    vec2 fringe = centered * 0.003 * reach;
    vec3 c = vec3(texture(InSampler, uv + fringe).r, texture(InSampler, uv).g, texture(InSampler, uv - fringe).b);

    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(c, vec3(luma) * vec3(0.85, 1.05, 0.7), 0.2);
    c = mix(c, vec3(0.25, 0.4, 0.1), 0.15 * reach);
    fragColor = vec4(c, 1.0);
}
