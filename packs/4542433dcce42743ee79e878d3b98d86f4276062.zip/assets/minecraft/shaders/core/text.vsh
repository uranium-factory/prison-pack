#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;

#ifdef IS_GUI
    // prison: the upgrade panel (hud/UpgradeHud) into the bottom-right corner
    if ((ivec3(round(Color.rgb * 255.0)) & 7) == ivec3(1, 3, 5)) {
        float w = 2.0 / ProjMat[0][0];
        float h = -2.0 / ProjMat[1][1];
        float origin = floor(w / 2.0);
        if (Position.x >= origin - 2.0 && Position.x <= origin + 132.0 + 2.0
                && Position.y >= 54.0 - 5.0 && Position.y <= 120.0 - 1.0) {
            vec2 shift = vec2(w - 4.0 - 132.0 - origin, h - 4.0 - 120.0 + 3.0);
            if (w - 4.0 - 132.0 < origin + 95.0) {
                shift.y -= 52.0;
            }
            gl_Position = ProjMat * ModelViewMat * vec4(Position.xy + shift, Position.z, 1.0);
        }
    }
#endif
}
