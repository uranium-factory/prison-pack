#version 330
#extension GL_ARB_separate_shader_objects : require

// Prison look (post_effect/grade.json, ResourcePackService): glow around bright pixels (lava, glowstone, ore light),
// gentle S-curve and saturation, cool shadows / warm highlights, soft vignette. Runs after the world, before the GUI.

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

const int GLOW_TAPS = 12;
const float GLOW_RADIUS = 0.02;      // of screen height
const float GLOW_THRESHOLD = 0.85;
const float GLOW_STRENGTH = 0.55;

void main() {
    vec3 c = texture(InSampler, texCoord).rgb;

    // Golden-angle spiral around the pixel; only what is brighter than the threshold bleeds.
    vec3 glow = vec3(0.0);
    for (int i = 0; i < GLOW_TAPS; i++) {
        float angle = float(i) * 2.3999632;
        float radius = sqrt((float(i) + 0.5) / float(GLOW_TAPS)) * GLOW_RADIUS;
        vec2 uv = texCoord + vec2(cos(angle) * InSize.y / InSize.x, sin(angle)) * radius;
        glow += max(texture(InSampler, uv).rgb - GLOW_THRESHOLD, 0.0);
    }
    c += glow / float(GLOW_TAPS) * GLOW_STRENGTH * 6.0;

    c = clamp(c, 0.0, 1.0);
    c = mix(c, c * c * (3.0 - 2.0 * c), 0.25);
    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(vec3(luma), c, 1.1);
    c *= mix(vec3(0.97, 0.99, 1.03), vec3(1.03, 1.0, 0.96), luma);

    vec2 d = (texCoord - 0.5) * vec2(InSize.x / InSize.y, 1.0);
    c *= 1.0 - 0.28 * smoothstep(0.55, 1.05, length(d));

    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
